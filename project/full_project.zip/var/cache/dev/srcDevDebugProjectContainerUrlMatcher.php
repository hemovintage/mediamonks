<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = $allowSchemes = array();
        if ($ret = $this->doMatch($pathinfo, $allow, $allowSchemes)) {
            return $ret;
        }
        if ($allow) {
            throw new MethodNotAllowedException(array_keys($allow));
        }
        if (!in_array($this->context->getMethod(), array('HEAD', 'GET'), true)) {
            // no-op
        } elseif ($allowSchemes) {
            redirect_scheme:
            $scheme = $this->context->getScheme();
            $this->context->setScheme(key($allowSchemes));
            try {
                if ($ret = $this->doMatch($pathinfo)) {
                    return $this->redirect($pathinfo, $ret['_route'], $this->context->getScheme()) + $ret;
                }
            } finally {
                $this->context->setScheme($scheme);
            }
        } elseif ('/' !== $pathinfo) {
            $pathinfo = '/' !== $pathinfo[-1] ? $pathinfo.'/' : substr($pathinfo, 0, -1);
            if ($ret = $this->doMatch($pathinfo, $allow, $allowSchemes)) {
                return $this->redirect($pathinfo, $ret['_route']) + $ret;
            }
            if ($allowSchemes) {
                goto redirect_scheme;
            }
        }

        throw new ResourceNotFoundException();
    }

    private function doMatch(string $rawPathinfo, array &$allow = array(), array &$allowSchemes = array()): ?array
    {
        $allow = $allowSchemes = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $context = $this->context;
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        switch ($pathinfo) {
            case '/':
                // homepage
                return array('_route' => 'homepage', '_controller' => 'App\\Controller\\BlogController::entriesAction');
                // entries
                return array('_route' => 'entries', '_controller' => 'App\\Controller\\BlogController::entriesAction');
                break;
            default:
                $routes = array(
                    '/admin/' => array(array('_route' => 'admin_index', '_controller' => 'App\\Controller\\AdminController::entriesAction'), null, null, null),
                    '/admin/entries' => array(array('_route' => 'admin_entries', '_controller' => 'App\\Controller\\AdminController::entriesAction'), null, null, null),
                    '/admin/create-entry' => array(array('_route' => 'admin_create_entry', '_controller' => 'App\\Controller\\AdminController::createEntryAction'), null, null, null),
                    '/admin/author/create' => array(array('_route' => 'author_create', '_controller' => 'App\\Controller\\AdminController::createAuthorAction'), null, null, null),
                    '/api' => array(array('_route' => 'api', '_controller' => 'App\\Controller\\ApiController::index'), null, null, null),
                    '/api/blogs' => array(array('_route' => 'api_blogs', '_controller' => 'App\\Controller\\ApiController::entriesAction'), null, null, null),
                    '/_profiler/' => array(array('_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'), null, null, null),
                    '/_profiler/search' => array(array('_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'), null, null, null),
                    '/_profiler/search_bar' => array(array('_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'), null, null, null),
                    '/_profiler/phpinfo' => array(array('_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'), null, null, null),
                    '/_profiler/open' => array(array('_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'), null, null, null),
                    '/login/' => array(array('_route' => 'hwi_oauth_connect', '_controller' => 'HWI\\Bundle\\OAuthBundle\\Controller\\ConnectController::connectAction'), null, null, null),
                    '/auth0/callback' => array(array('_route' => 'auth0_login'), null, null, null),
                    '/auth0/logout' => array(array('_route' => 'auth0_logout'), null, null, null),
                );

                if (!isset($routes[$pathinfo])) {
                    break;
                }
                list($ret, $requiredHost, $requiredMethods, $requiredSchemes) = $routes[$pathinfo];

                $hasRequiredScheme = !$requiredSchemes || isset($requiredSchemes[$context->getScheme()]);
                if ($requiredMethods && !isset($requiredMethods[$canonicalMethod]) && !isset($requiredMethods[$requestMethod])) {
                    if ($hasRequiredScheme) {
                        $allow += $requiredMethods;
                    }
                    break;
                }
                if (!$hasRequiredScheme) {
                    $allowSchemes += $requiredSchemes;
                    break;
                }

                return $ret;
        }

        $matchedPathinfo = $pathinfo;
        $regexList = array(
            0 => '{^(?'
                    .'|/a(?'
                        .'|dmin/(?'
                            .'|edit\\-entry/([^/]++)(*:40)'
                            .'|delete\\-entry/([^/]++)(*:69)'
                        .')'
                        .'|pi/blogs/([^/]++)(*:94)'
                        .'|uthor/([^/]++)(*:115)'
                    .')'
                    .'|/entry/([^/]++)(*:139)'
                    .'|/_(?'
                        .'|error/(\\d+)(?:\\.([^/]++))?(*:178)'
                        .'|wdt/([^/]++)(*:198)'
                        .'|profiler/([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:244)'
                                .'|router(*:258)'
                                .'|exception(?'
                                    .'|(*:278)'
                                    .'|\\.css(*:291)'
                                .')'
                            .')'
                            .'|(*:301)'
                        .')'
                    .')'
                    .'|/connect/([^/]++)(*:328)'
                .')$}sD',
        );

        foreach ($regexList as $offset => $regex) {
            while (preg_match($regex, $matchedPathinfo, $matches)) {
                switch ($m = (int) $matches['MARK']) {
                    default:
                        $routes = array(
                            40 => array(array('_route' => 'admin_edit_entry', '_controller' => 'App\\Controller\\AdminController::editEntryAction'), array('entryId'), null, null),
                            69 => array(array('_route' => 'admin_delete_entry', '_controller' => 'App\\Controller\\AdminController::deleteEntryAction'), array('entryId'), null, null),
                            94 => array(array('_route' => 'api_blogs_id', '_controller' => 'App\\Controller\\ApiController::entryAction'), array('id'), null, null),
                            115 => array(array('_route' => 'author', '_controller' => 'App\\Controller\\BlogController::authorAction'), array('name'), null, null),
                            139 => array(array('_route' => 'entry', '_controller' => 'App\\Controller\\BlogController::entryAction'), array('slug'), null, null),
                            178 => array(array('_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code', '_format'), null, null),
                            198 => array(array('_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'), array('token'), null, null),
                            244 => array(array('_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array('token'), null, null),
                            258 => array(array('_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'), array('token'), null, null),
                            278 => array(array('_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception::showAction'), array('token'), null, null),
                            291 => array(array('_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception::cssAction'), array('token'), null, null),
                            301 => array(array('_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'), array('token'), null, null),
                            328 => array(array('_route' => 'hwi_oauth_service_redirect', '_controller' => 'HWI\\Bundle\\OAuthBundle\\Controller\\ConnectController::redirectToServiceAction'), array('service'), null, null),
                        );

                        list($ret, $vars, $requiredMethods, $requiredSchemes) = $routes[$m];

                        foreach ($vars as $i => $v) {
                            if (isset($matches[1 + $i])) {
                                $ret[$v] = $matches[1 + $i];
                            }
                        }

                        $hasRequiredScheme = !$requiredSchemes || isset($requiredSchemes[$context->getScheme()]);
                        if ($requiredMethods && !isset($requiredMethods[$canonicalMethod]) && !isset($requiredMethods[$requestMethod])) {
                            if ($hasRequiredScheme) {
                                $allow += $requiredMethods;
                            }
                            break;
                        }
                        if (!$hasRequiredScheme) {
                            $allowSchemes += $requiredSchemes;
                            break;
                        }

                        return $ret;
                }

                if (328 === $m) {
                    break;
                }
                $regex = substr_replace($regex, 'F', $m - $offset, 1 + strlen($m));
                $offset += strlen($m);
            }
        }
        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        return null;
    }
}
