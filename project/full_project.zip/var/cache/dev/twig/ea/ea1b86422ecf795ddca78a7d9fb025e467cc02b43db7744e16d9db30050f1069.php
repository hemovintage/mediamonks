<?php

/* blog/entries.html.twig */
class __TwigTemplate_27c6e3420388ffbdaa2d0ef6f172cf838625f7b85bd171ff59637566c6d3060d extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/entries.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/entries.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/entries.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "App:blog:entries";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"container\">
    <div class=\"blog-header\">
        <h1 class=\"blog-title\">Media Monks Blog Test</h1>
        <p class=\"lead blog-description\">a blog test in Symfony 4 + SQLite + Docker + Bootstrap 3 by <a href=\"https://www.linkedin.com/in/hemovintage/\">José 'Hemo' Pérez</a>.</p>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-8 blog-main\">
            ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blogPosts"]) || array_key_exists("blogPosts", $context) ? $context["blogPosts"] : (function () { throw new Twig_Error_Runtime('Variable "blogPosts" does not exist.', 14, $this->source); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["blogPost"]) {
            // line 15
            echo "                ";
            $context["paragraphs"] = twig_split_filter($this->env, twig_get_attribute($this->env, $this->source, $context["blogPost"], "synopsis", array()), "</p>");
            // line 16
            echo "                ";
            $context["firstParagraph"] = (twig_first($this->env, (isset($context["paragraphs"]) || array_key_exists("paragraphs", $context) ? $context["paragraphs"] : (function () { throw new Twig_Error_Runtime('Variable "paragraphs" does not exist.', 16, $this->source); })())) . "</p>");
            // line 17
            echo "                <div class=\"blog-post\">
                    <h2 class=\"blog-post-title\">
                        <a href=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("entry", array("slug" => twig_get_attribute($this->env, $this->source, $context["blogPost"], "slug", array()))), "html", null, true);
            echo "\">
\t\t\t\t\t\t    ";
            // line 20
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["blogPost"], "title", array()), "html", null, true);
            echo "
\t\t\t\t\t\t</a>
                    </h2>
                    <p class=\"blog-post-meta\">
                        ";
            // line 24
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["blogPost"], "getUpdatedAt", array()), "F j, Y"), "html", null, true);
            echo " by

\t\t\t\t\t\t";
            // line 26
            if (twig_get_attribute($this->env, $this->source, $context["blogPost"], "author", array())) {
                // line 27
                echo "\t\t\t\t\t\t    <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("author", array("name" => twig_urlencode_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["blogPost"], "author", array()), "username", array())))), "html", null, true);
                echo "\">
\t\t\t\t\t\t        ";
                // line 28
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["blogPost"], "author", array()), "name", array()), "html", null, true);
                echo "
\t\t\t\t\t\t    </a>
\t\t\t\t\t\t";
            } else {
                // line 31
                echo "                            Unknown Author
                        ";
            }
            // line 33
            echo "                    </p>
                    ";
            // line 34
            echo (isset($context["firstParagraph"]) || array_key_exists("firstParagraph", $context) ? $context["firstParagraph"] : (function () { throw new Twig_Error_Runtime('Variable "firstParagraph" does not exist.', 34, $this->source); })());
            echo "<br />

                    ";
            // line 36
            if (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["blogPost"], "tag", array()))) {
                // line 37
                echo "                    <p>tags: 
                        <ul class=\"list-inline\">
                            ";
                // line 39
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["blogPost"], "tag", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                    // line 40
                    echo "                                <li class=\"list-inline-item\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "name", array()), "html", null, true);
                    echo "</li>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 42
                echo "                        </ul>
                    </p>
                    ";
            }
            // line 45
            echo "
                    <a href=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("entry", array("slug" => twig_get_attribute($this->env, $this->source, $context["blogPost"], "slug", array()))), "html", null, true);
            echo "\">Read more</a>
                </div>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 49
            echo "                <div class=\"alert alert-danger\" role=\"alert\">
                    <span class=\"glyphicon glyphicon-exclamation-sign\" aria-hidden=\"true\"></span>
                    <span class=\"sr-only\">Error:</span>
                    You have no blog articles. Please log in and create an article.
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blogPost'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 55
        echo "
            ";
        // line 56
        $context["canPrevious"] = ((isset($context["page"]) || array_key_exists("page", $context) ? $context["page"] : (function () { throw new Twig_Error_Runtime('Variable "page" does not exist.', 56, $this->source); })()) > 1);
        // line 57
        echo "            ";
        $context["canNext"] = (((isset($context["page"]) || array_key_exists("page", $context) ? $context["page"] : (function () { throw new Twig_Error_Runtime('Variable "page" does not exist.', 57, $this->source); })()) * (isset($context["entryLimit"]) || array_key_exists("entryLimit", $context) ? $context["entryLimit"] : (function () { throw new Twig_Error_Runtime('Variable "entryLimit" does not exist.', 57, $this->source); })())) < (isset($context["totalBlogPosts"]) || array_key_exists("totalBlogPosts", $context) ? $context["totalBlogPosts"] : (function () { throw new Twig_Error_Runtime('Variable "totalBlogPosts" does not exist.', 57, $this->source); })()));
        // line 58
        echo "            <nav>
                <ul class=\"pager\">
                    <li class=\"previous ";
        // line 60
        if (((isset($context["canPrevious"]) || array_key_exists("canPrevious", $context) ? $context["canPrevious"] : (function () { throw new Twig_Error_Runtime('Variable "canPrevious" does not exist.', 60, $this->source); })()) == false)) {
            echo "disabled";
        }
        echo "\">
                        <a href=\"";
        // line 61
        if ((isset($context["canPrevious"]) || array_key_exists("canPrevious", $context) ? $context["canPrevious"] : (function () { throw new Twig_Error_Runtime('Variable "canPrevious" does not exist.', 61, $this->source); })())) {
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("entries", array("page" => ((isset($context["page"]) || array_key_exists("page", $context) ? $context["page"] : (function () { throw new Twig_Error_Runtime('Variable "page" does not exist.', 61, $this->source); })()) - 1))), "html", null, true);
        }
        echo "\">
                            <span aria-hidden=\"true\">&larr;</span> Older
                        </a>
                    </li>
                    <li class=\"next ";
        // line 65
        if (((isset($context["canNext"]) || array_key_exists("canNext", $context) ? $context["canNext"] : (function () { throw new Twig_Error_Runtime('Variable "canNext" does not exist.', 65, $this->source); })()) == false)) {
            echo "disabled";
        }
        echo "\">
                        <a href=\"";
        // line 66
        if ((isset($context["canNext"]) || array_key_exists("canNext", $context) ? $context["canNext"] : (function () { throw new Twig_Error_Runtime('Variable "canNext" does not exist.', 66, $this->source); })())) {
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("entries", array("page" => ((isset($context["page"]) || array_key_exists("page", $context) ? $context["page"] : (function () { throw new Twig_Error_Runtime('Variable "page" does not exist.', 66, $this->source); })()) + 1))), "html", null, true);
        }
        echo "\">
                            Newer <span aria-hidden=\"true\">&rarr;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/entries.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 66,  211 => 65,  202 => 61,  196 => 60,  192 => 58,  189 => 57,  187 => 56,  184 => 55,  173 => 49,  165 => 46,  162 => 45,  157 => 42,  148 => 40,  144 => 39,  140 => 37,  138 => 36,  133 => 34,  130 => 33,  126 => 31,  120 => 28,  115 => 27,  113 => 26,  108 => 24,  101 => 20,  97 => 19,  93 => 17,  90 => 16,  87 => 15,  82 => 14,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}App:blog:entries{% endblock %}

{% block body %}
<div class=\"container\">
    <div class=\"blog-header\">
        <h1 class=\"blog-title\">Media Monks Blog Test</h1>
        <p class=\"lead blog-description\">a blog test in Symfony 4 + SQLite + Docker + Bootstrap 3 by <a href=\"https://www.linkedin.com/in/hemovintage/\">José 'Hemo' Pérez</a>.</p>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-8 blog-main\">
            {% for blogPost in blogPosts %}
                {% set paragraphs = blogPost.synopsis|split('</p>') %}
                {% set firstParagraph = paragraphs|first ~ '</p>' %}
                <div class=\"blog-post\">
                    <h2 class=\"blog-post-title\">
                        <a href=\"{{ path('entry', {'slug': blogPost.slug}) }}\">
\t\t\t\t\t\t    {{ blogPost.title }}
\t\t\t\t\t\t</a>
                    </h2>
                    <p class=\"blog-post-meta\">
                        {{ blogPost.getUpdatedAt|date('F j, Y') }} by

\t\t\t\t\t\t{% if blogPost.author %}
\t\t\t\t\t\t    <a href=\"{{ path('author', {'name': blogPost.author.username|url_encode }) }}\">
\t\t\t\t\t\t        {{ blogPost.author.name }}
\t\t\t\t\t\t    </a>
\t\t\t\t\t\t{% else %}
                            Unknown Author
                        {% endif %}
                    </p>
                    {{ firstParagraph|raw }}<br />

                    {% if blogPost.tag|length %}
                    <p>tags: 
                        <ul class=\"list-inline\">
                            {% for item in blogPost.tag %}
                                <li class=\"list-inline-item\">{{ item.name }}</li>
                            {% endfor %}
                        </ul>
                    </p>
                    {% endif %}

                    <a href=\"{{ path('entry', {'slug': blogPost.slug}) }}\">Read more</a>
                </div>
            {% else %}
                <div class=\"alert alert-danger\" role=\"alert\">
                    <span class=\"glyphicon glyphicon-exclamation-sign\" aria-hidden=\"true\"></span>
                    <span class=\"sr-only\">Error:</span>
                    You have no blog articles. Please log in and create an article.
                </div>
            {% endfor %}

            {% set canPrevious = page > 1 %}
            {% set canNext = (page * entryLimit) < totalBlogPosts %}
            <nav>
                <ul class=\"pager\">
                    <li class=\"previous {% if canPrevious == false %}disabled{% endif %}\">
                        <a href=\"{% if canPrevious %}{{ path('entries', {'page': page - 1}) }}{% endif %}\">
                            <span aria-hidden=\"true\">&larr;</span> Older
                        </a>
                    </li>
                    <li class=\"next {% if canNext == false %}disabled{% endif %}\">
                        <a href=\"{% if canNext %}{{ path('entries', {'page': page + 1}) }}{% endif %}\">
                            Newer <span aria-hidden=\"true\">&rarr;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
{% endblock %}", "blog/entries.html.twig", "/application/project/templates/blog/entries.html.twig");
    }
}
