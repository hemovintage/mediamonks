<?php

/* blog/entry.html.twig */
class __TwigTemplate_83e1b9e25d2b71cdad3024df9e5318d6d69ee74054587bb5881a8db7d8bed692 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/entry.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/entry.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/entry.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "App:blog:entry";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"container\">
    <div class=\"blog-header\">
        <h1 class=\"blog-title\">Media Monks Blog Test</h1>
        <p class=\"lead blog-description\">a blog test in Symfony 4 + SQLite + Docker + Bootstrap 3 by <a href=\"https://www.linkedin.com/in/hemovintage/\">José 'Hemo' Pérez</a>.</p>
    </div>

    <div class=\"row\">
    <div class=\"col-sm-8 blog-main\">
        <div class=\"blog-post\">
            <h2 class=\"blog-post-title\">";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 15, $this->source); })()), "title", array()), "html", null, true);
        echo "</h2>
            <p class=\"blog-post-meta\">
            ";
        // line 17
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 17, $this->source); })()), "updatedAt", array()), "F j, Y"), "html", null, true);
        echo " by <a href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("author", array("name" => twig_urlencode_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 17, $this->source); })()), "author", array()), "username", array())))), "html", null, true);
        echo "\">
                ";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 18, $this->source); })()), "author", array()), "name", array()), "html", null, true);
        echo "
                </a>
            </p>
            <p>";
        // line 21
        echo twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 21, $this->source); })()), "synopsis", array());
        echo "</p>

            <p>";
        // line 23
        echo twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 23, $this->source); })()), "body", array());
        echo "</p>

        ";
        // line 25
        if (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 25, $this->source); })()), "tag", array()))) {
            // line 26
            echo "        <p>tags:
            <ul class=\"list-inline\">
                ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["blogPost"]) || array_key_exists("blogPost", $context) ? $context["blogPost"] : (function () { throw new Twig_Error_Runtime('Variable "blogPost" does not exist.', 28, $this->source); })()), "tag", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 29
                echo "                    <li class=\"list-inline-item\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "name", array()), "html", null, true);
                echo "</li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "            </ul>   
        </p>
        ";
        }
        // line 34
        echo "     </div>
    </div>
    </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "blog/entry.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 34,  129 => 31,  120 => 29,  116 => 28,  112 => 26,  110 => 25,  105 => 23,  100 => 21,  94 => 18,  88 => 17,  83 => 15,  72 => 6,  63 => 5,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block title %}App:blog:entry{% endblock %}

{% block body %}
<div class=\"container\">
    <div class=\"blog-header\">
        <h1 class=\"blog-title\">Media Monks Blog Test</h1>
        <p class=\"lead blog-description\">a blog test in Symfony 4 + SQLite + Docker + Bootstrap 3 by <a href=\"https://www.linkedin.com/in/hemovintage/\">José 'Hemo' Pérez</a>.</p>
    </div>

    <div class=\"row\">
    <div class=\"col-sm-8 blog-main\">
        <div class=\"blog-post\">
            <h2 class=\"blog-post-title\">{{ blogPost.title }}</h2>
            <p class=\"blog-post-meta\">
            {{ blogPost.updatedAt|date('F j, Y') }} by <a href=\"{{ path('author', {'name': blogPost.author.username|url_encode }) }}\">
                {{ blogPost.author.name }}
                </a>
            </p>
            <p>{{ blogPost.synopsis|raw }}</p>

            <p>{{ blogPost.body|raw }}</p>

        {% if blogPost.tag|length %}
        <p>tags:
            <ul class=\"list-inline\">
                {% for item in blogPost.tag %}
                    <li class=\"list-inline-item\">{{ item.name }}</li>
                {% endfor %}
            </ul>   
        </p>
        {% endif %}
     </div>
    </div>
    </div>
</div>
{% endblock %}", "blog/entry.html.twig", "/application/project/templates/blog/entry.html.twig");
    }
}
