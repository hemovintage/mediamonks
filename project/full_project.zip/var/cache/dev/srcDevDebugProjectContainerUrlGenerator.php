<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class srcDevDebugProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;
    private $defaultLocale;

    public function __construct(RequestContext $context, LoggerInterface $logger = null, string $defaultLocale = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        $this->defaultLocale = $defaultLocale;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'admin_index' => array(array(), array('_controller' => 'App\\Controller\\AdminController::entriesAction'), array(), array(array('text', '/admin/')), array(), array()),
        'admin_entries' => array(array(), array('_controller' => 'App\\Controller\\AdminController::entriesAction'), array(), array(array('text', '/admin/entries')), array(), array()),
        'admin_create_entry' => array(array(), array('_controller' => 'App\\Controller\\AdminController::createEntryAction'), array(), array(array('text', '/admin/create-entry')), array(), array()),
        'admin_edit_entry' => array(array('entryId'), array('_controller' => 'App\\Controller\\AdminController::editEntryAction'), array(), array(array('variable', '/', '[^/]++', 'entryId'), array('text', '/admin/edit-entry')), array(), array()),
        'admin_delete_entry' => array(array('entryId'), array('_controller' => 'App\\Controller\\AdminController::deleteEntryAction'), array(), array(array('variable', '/', '[^/]++', 'entryId'), array('text', '/admin/delete-entry')), array(), array()),
        'author_create' => array(array(), array('_controller' => 'App\\Controller\\AdminController::createAuthorAction'), array(), array(array('text', '/admin/author/create')), array(), array()),
        'api' => array(array(), array('_controller' => 'App\\Controller\\ApiController::index'), array(), array(array('text', '/api')), array(), array()),
        'api_blogs' => array(array(), array('_controller' => 'App\\Controller\\ApiController::entriesAction'), array(), array(array('text', '/api/blogs')), array(), array()),
        'api_blogs_id' => array(array('id'), array('_controller' => 'App\\Controller\\ApiController::entryAction'), array(), array(array('variable', '/', '[^/]++', 'id'), array('text', '/api/blogs')), array(), array()),
        'homepage' => array(array(), array('_controller' => 'App\\Controller\\BlogController::entriesAction'), array(), array(array('text', '/')), array(), array()),
        'entries' => array(array(), array('_controller' => 'App\\Controller\\BlogController::entriesAction'), array(), array(array('text', '/')), array(), array()),
        'entry' => array(array('slug'), array('_controller' => 'App\\Controller\\BlogController::entryAction'), array(), array(array('variable', '/', '[^/]++', 'slug'), array('text', '/entry')), array(), array()),
        'author' => array(array('name'), array('_controller' => 'App\\Controller\\BlogController::authorAction'), array(), array(array('variable', '/', '[^/]++', 'name'), array('text', '/author')), array(), array()),
        '_twig_error_test' => array(array('code', '_format'), array('_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'), array('code' => '\\d+'), array(array('variable', '.', '[^/]++', '_format'), array('variable', '/', '\\d+', 'code'), array('text', '/_error')), array(), array()),
        '_wdt' => array(array('token'), array('_controller' => 'web_profiler.controller.profiler::toolbarAction'), array(), array(array('variable', '/', '[^/]++', 'token'), array('text', '/_wdt')), array(), array()),
        '_profiler_home' => array(array(), array('_controller' => 'web_profiler.controller.profiler::homeAction'), array(), array(array('text', '/_profiler/')), array(), array()),
        '_profiler_search' => array(array(), array('_controller' => 'web_profiler.controller.profiler::searchAction'), array(), array(array('text', '/_profiler/search')), array(), array()),
        '_profiler_search_bar' => array(array(), array('_controller' => 'web_profiler.controller.profiler::searchBarAction'), array(), array(array('text', '/_profiler/search_bar')), array(), array()),
        '_profiler_phpinfo' => array(array(), array('_controller' => 'web_profiler.controller.profiler::phpinfoAction'), array(), array(array('text', '/_profiler/phpinfo')), array(), array()),
        '_profiler_search_results' => array(array('token'), array('_controller' => 'web_profiler.controller.profiler::searchResultsAction'), array(), array(array('text', '/search/results'), array('variable', '/', '[^/]++', 'token'), array('text', '/_profiler')), array(), array()),
        '_profiler_open_file' => array(array(), array('_controller' => 'web_profiler.controller.profiler::openAction'), array(), array(array('text', '/_profiler/open')), array(), array()),
        '_profiler' => array(array('token'), array('_controller' => 'web_profiler.controller.profiler::panelAction'), array(), array(array('variable', '/', '[^/]++', 'token'), array('text', '/_profiler')), array(), array()),
        '_profiler_router' => array(array('token'), array('_controller' => 'web_profiler.controller.router::panelAction'), array(), array(array('text', '/router'), array('variable', '/', '[^/]++', 'token'), array('text', '/_profiler')), array(), array()),
        '_profiler_exception' => array(array('token'), array('_controller' => 'web_profiler.controller.exception::showAction'), array(), array(array('text', '/exception'), array('variable', '/', '[^/]++', 'token'), array('text', '/_profiler')), array(), array()),
        '_profiler_exception_css' => array(array('token'), array('_controller' => 'web_profiler.controller.exception::cssAction'), array(), array(array('text', '/exception.css'), array('variable', '/', '[^/]++', 'token'), array('text', '/_profiler')), array(), array()),
        'hwi_oauth_service_redirect' => array(array('service'), array('_controller' => 'HWI\\Bundle\\OAuthBundle\\Controller\\ConnectController::redirectToServiceAction'), array(), array(array('variable', '/', '[^/]++', 'service'), array('text', '/connect')), array(), array()),
        'hwi_oauth_connect' => array(array(), array('_controller' => 'HWI\\Bundle\\OAuthBundle\\Controller\\ConnectController::connectAction'), array(), array(array('text', '/login/')), array(), array()),
        'auth0_login' => array(array(), array(), array(), array(array('text', '/auth0/callback')), array(), array()),
        'auth0_logout' => array(array(), array(), array(), array(array('text', '/auth0/logout')), array(), array()),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        $locale = $parameters['_locale']
            ?? $this->context->getParameter('_locale')
            ?: $this->defaultLocale;

        if (null !== $locale && (self::$declaredRoutes[$name.'.'.$locale][1]['_canonical_route'] ?? null) === $name) {
            unset($parameters['_locale']);
            $name .= '.'.$locale;
        } elseif (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
