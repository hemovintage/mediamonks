var $ = require('jquery');
require('bootstrap-sass');
require('../css/main.scss');